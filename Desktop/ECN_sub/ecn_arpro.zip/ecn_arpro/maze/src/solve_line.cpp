#include <a_star.h>
#include <maze.h>

using namespace std;
using namespace ecn;

// a node is a x-y position, we move from 1 each time
class Position : public Point
{
    typedef std::unique_ptr<Position> PositionPtr;

public:
    // constructor from coordinates
    Position(int _x, int _y) : Point(_x, _y) {}

    // constructor from base ecn::Point
    Position(ecn::Point p) : Point(p.x, p.y) {}

    Position(int _x,int _y, int _dis):Point(_x,_y,_dis){}

    int distToParent()
    {
       return dis;
    }

    bool is_corridor(int x,int y){
        if((!maze.cell(x,y+1))&&(!maze.cell(x,y-1))){
            return 1;
        }else if((!maze.cell(x-1,y))&&(!maze.cell(x+1,y))){
            return 1;
        }
        return 0;

    }

    std::vector<PositionPtr> children()
    {
        // this method should return  all positions reachable from this one
        std::vector<PositionPtr> generated;
        //up, down, right, left of the parent node
        std::pair<int, int> up=std::make_pair(x,y+1);
        std::pair<int, int> down=std::make_pair(x,y-1);
        std::pair<int, int> right=std::make_pair(x+1,y);
        std::pair<int, int> left=std::make_pair(x-1,y);

        int dis_u=0;
        int dis_d=0;
        int dis_r=0;
        int dis_l=0;

        if(maze.cell(up.first,up.second)){
             while((is_corridor(up.first,up.second+dis_u))&&(maze.cell(up.first,up.second+dis_u))){
                dis_u=dis_u+1;
            }
            generated.push_back(PositionPtr(new Position(up.first,up.second+dis_u,dis_u+1)));
        }

        if(maze.cell(down.first,down.second)){
             while((is_corridor(down.first,down.second-dis_d))&&(maze.cell(down.first,down.second-dis_d))){
                dis_d=dis_d+1;
            }
            generated.push_back(PositionPtr(new Position(down.first,down.second-dis_d,dis_d+1)));
        }

        if(maze.cell(right.first,right.second)){
             while((is_corridor(right.first+dis_r,right.second))&&(maze.cell(right.first+dis_r,right.second))){
                dis_r=dis_r+1;
            }
            generated.push_back(PositionPtr(new Position(right.first+dis_r,right.second,dis_r+1)));
        }

        if(maze.cell(left.first,left.second)){
             while((is_corridor(left.first-dis_l,left.second))&&(maze.cell(down.first-dis_l,down.second))){
                dis_l=dis_l+1;
            }
            generated.push_back(PositionPtr(new Position(left.first-dis_l,left.second,dis_l+1)));
        }




        return generated;
    }
};



int main( int argc, char **argv )
{
    // load file
    std::string filename = "maze.png";
    if(argc == 2)
        filename = std::string(argv[1]);

    // let Point know about this maze
    Position::maze = ecn::Maze(filename);

    // initial and goal positions as Position's
    Position start = Position::maze.start(),
             goal = Position::maze.end();

    // call A* algorithm
    ecn::Astar(start, goal);

    // save final image
    Position::maze.saveSolution("cell");
    cv::waitKey(0);

}
