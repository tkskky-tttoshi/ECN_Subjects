#include <a_star.h>
#include <maze.h>

using namespace std;
using namespace ecn;

// a node is a x-y position, we move from 1 each time
class Position : public Point
{
    typedef std::unique_ptr<Position> PositionPtr;

public:
    // constructor from coordinates
    Position(int _x, int _y) : Point(_x, _y) {}

    // constructor from base ecn::Point
    Position(ecn::Point p) : Point(p.x, p.y) {}

    Position(int _x,int _y, int _dis):Point(_x,_y,_dis){}

    int distToParent()
    {
       return dis;
    }

    bool is_corridor(int x,int y){
        if((!maze.cell(x,y+1))&&(!maze.cell(x,y-1))){
            return 1;
        }else if((!maze.cell(x-1,y))&&(!maze.cell(x+1,y))){
            return 1;
        }
        return 0;

    }

    int is_simple_corner(int x_,int y_){

        //if the current node is on the simple corner, this returns 1,2,3, or 4. There are 4 kinds of simple corners.
        //if it is not on the simple corner, this returns 0

        int type=0;
        std::pair<int, int> up=std::make_pair(x_,y_+1);
        std::pair<int, int> down=std::make_pair(x_,y_-1);
        std::pair<int, int> right=std::make_pair(x_+1,y_);
        std::pair<int, int> left=std::make_pair(x_-1,y_);

        bool u_=maze.cell(up.first,up.second);
        bool d_=maze.cell(down.first,down.second);
        bool r_=maze.cell(right.first,right.second);
        bool l_=maze.cell(left.first,left.second);

        if(u_&&(!d_)&&r_&&(!l_)){
            type=1;
        }else if(u_&&(!d_)&&(!r_)&&l_){
            type=2;
        }else if((!u_)&&d_&&r_&&(!l_)){
            type=3;
        }else if((!u_)&&d_&&(!r_)&&l_){
            type=4;
        }

        return type;

    }

    int calDis(int x_,int y_){
        bool check=true;

        std::pair<int, int> up=std::make_pair(x_,y_+1);
        std::pair<int, int> down=std::make_pair(x_,y_-1);
        std::pair<int, int> right=std::make_pair(x_+1,y_);
        std::pair<int, int> left=std::make_pair(x_-1,y_);

        int dis_u=0;
        int dis_d=0;
        int dis_r=0;
        int dis_l=0;






    }

    std::vector<PositionPtr> children()
    {
        // this method should return  all positions reachable from this one
        std::vector<PositionPtr> generated;
        //up, down, right, left of the parent node
        std::pair<int, int> up=std::make_pair(x,y+1);
        std::pair<int, int> down=std::make_pair(x,y-1);
        std::pair<int, int> right=std::make_pair(x+1,y);
        std::pair<int, int> left=std::make_pair(x-1,y);

        int pre_x;
        int pre_y;

        int dis_u=1;
        int dis_d=1;
        int dis_r=1;
        int dis_l=1;

        int cur_x=x+dis_r-dis_l;
        int cur_y=y+dis_u-dis_d;

        bool check;
        int type;


        if(maze.cell(x,y+1)){
            while((is_corridor(x,y+dis_u))&&(maze.cell(x,y+dis_u))){
                pre_x=x;
                pre_y=y+dis_u;
                dis_u=dis_u+1;
            }
            type=is_simple_corner(x,y+dis_u);
            while(type!=0){
                if(type==1){
                    if((pre_x==cur_x)&&(pre_y==cur_y+1)){
                        dis_r=dis_r+1;
                        while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                            dis_r=dis_r+1;
                        }
                    }else if((pre_x==cur_x+1)&&(pre_y==cur_y)){
                        dis_u=dis_u+1;
                        while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                            dis_u+dis_u+1;
                        }

                    }
                }else if(type==2){
                    if((pre_x==cur_x)&&(pre_y==cur_y+1)){
                        dis_l=dis_l+1;
                        while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                            dis_l=dis_l+1;
                        }
                     }else if((pre_x==cur_x-1)&&(pre_y==cur_y)){
                        dis_u=dis_u+1;
                        while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                            dis_u=dis_u+1;
                        }
                    }
                }else if(type==3){
                    if((pre_x==cur_x)&&(pre_y==cur_y-1)){
                        dis_r=dis_r+1;
                        while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                            dis_r=dis_r+1;
                        }
                     }else if((pre_x==cur_x+1)&&(pre_y==cur_y)){
                        dis_d=dis_d+1;
                        while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                            dis_d=dis_d+1;
                        }
                    }
                }else if(type==4){
                    if((pre_x==cur_x)&&(pre_y==cur_y-1)){
                        dis_l=dis_l+1;
                        while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                            dis_l=dis_l+1;
                        }
                     }else if((pre_x==cur_x-1)&&(pre_y==cur_y)){
                        dis_d=dis_d+1;
                        while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                            dis_d=dis_d+1;
                        }
                    }

                }
                generated.push_back(PositionPtr(new Position(cur_x,cur_y,dis_u+dis_d+dis_r+dis_l)));


            }
        }

            if(maze.cell(x,y-1)){
                while((is_corridor(x,y-dis_d))&&(maze.cell(x,y-dis_d))){
                    pre_x=x;
                    pre_y=y-dis_d;
                    dis_d=dis_d+1;
                }
                type=is_simple_corner(x,y-dis_d);
                while(type!=0){
                    if(type==1){
                        if((pre_x==cur_x)&&(pre_y==cur_y+1)){
                            dis_r=dis_r+1;
                            while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                dis_r=dis_r+1;
                            }
                        }else if((pre_x==cur_x+1)&&(pre_y==cur_y)){
                            dis_u=dis_u+1;
                            while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                dis_u+dis_u+1;
                            }

                        }
                    }else if(type==2){
                        if((pre_x==cur_x)&&(pre_y==cur_y+1)){
                            dis_l=dis_l+1;
                            while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                dis_l=dis_l+1;
                            }
                         }else if((pre_x==cur_x-1)&&(pre_y==cur_y)){
                            dis_u=dis_u+1;
                            while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                dis_u=dis_u+1;
                            }
                        }
                    }else if(type==3){
                        if((pre_x==cur_x)&&(pre_y==cur_y-1)){
                            dis_r=dis_r+1;
                            while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                dis_r=dis_r+1;
                            }
                         }else if((pre_x==cur_x+1)&&(pre_y==cur_y)){
                            dis_d=dis_d+1;
                            while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                dis_d=dis_d+1;
                            }
                        }
                    }else if(type==4){
                        if((pre_x==cur_x)&&(pre_y==cur_y-1)){
                            dis_l=dis_l+1;
                            while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                dis_l=dis_l+1;
                            }
                         }else if((pre_x==cur_x-1)&&(pre_y==cur_y)){
                            dis_d=dis_d+1;
                            while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                dis_d=dis_d+1;
                            }
                        }

                    }
                    generated.push_back(PositionPtr(new Position(cur_x,cur_y,dis_u+dis_d+dis_r+dis_l)));


                }
            }

                if(maze.cell(x+1,y)){
                    while((is_corridor(x+dis_r,y))&&(maze.cell(x+dis_r,y))){
                        pre_x=x+dis_r;
                        pre_y=y;
                        dis_r=dis_r+1;
                    }
                    type=is_simple_corner(x+dis_r,y);
                    while(type!=0){
                        if(type==1){
                            if((pre_x==cur_x)&&(pre_y==cur_y+1)){
                                dis_r=dis_r+1;
                                while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                    dis_r=dis_r+1;
                                }
                            }else if((pre_x==cur_x+1)&&(pre_y==cur_y)){
                                dis_u=dis_u+1;
                                while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                    dis_u+dis_u+1;
                                }

                            }
                        }else if(type==2){
                            if((pre_x==cur_x)&&(pre_y==cur_y+1)){
                                dis_l=dis_l+1;
                                while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                    dis_l=dis_l+1;
                                }
                             }else if((pre_x==cur_x-1)&&(pre_y==cur_y)){
                                dis_u=dis_u+1;
                                while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                    dis_u=dis_u+1;
                                }
                            }
                        }else if(type==3){
                            if((pre_x==cur_x)&&(pre_y==cur_y-1)){
                                dis_r=dis_r+1;
                                while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                    dis_r=dis_r+1;
                                }
                             }else if((pre_x==cur_x+1)&&(pre_y==cur_y)){
                                dis_d=dis_d+1;
                                while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                    dis_d=dis_d+1;
                                }
                            }
                        }else if(type==4){
                            if((pre_x==cur_x)&&(pre_y==cur_y-1)){
                                dis_l=dis_l+1;
                                while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                    dis_l=dis_l+1;
                                }
                             }else if((pre_x==cur_x-1)&&(pre_y==cur_y)){
                                dis_d=dis_d+1;
                                while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                    dis_d=dis_d+1;
                                }
                            }

                        }
                        generated.push_back(PositionPtr(new Position(cur_x,cur_y,dis_u+dis_d+dis_r+dis_l)));


                    }
                }

                    if(maze.cell(x-1,y)){
                        while((is_corridor(x-dis_l,y))&&(maze.cell(x-dis_l,y))){
                            pre_x=x-dis_l;
                            pre_y=y;
                            dis_l=dis_l+1;
                        }
                        type=is_simple_corner(x-dis_l,y);
                        while(type!=0){
                            if(type==1){
                                if((pre_x==cur_x)&&(pre_y==cur_y+1)){
                                    dis_r=dis_r+1;
                                    while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                        dis_r=dis_r+1;
                                    }
                                }else if((pre_x==cur_x+1)&&(pre_y==cur_y)){
                                    dis_u=dis_u+1;
                                    while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                        dis_u+dis_u+1;
                                    }

                                }
                            }else if(type==2){
                                if((pre_x==cur_x)&&(pre_y==cur_y+1)){
                                    dis_l=dis_l+1;
                                    while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                        dis_l=dis_l+1;
                                    }
                                 }else if((pre_x==cur_x-1)&&(pre_y==cur_y)){
                                    dis_u=dis_u+1;
                                    while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                        dis_u=dis_u+1;
                                    }
                                }
                            }else if(type==3){
                                if((pre_x==cur_x)&&(pre_y==cur_y-1)){
                                    dis_r=dis_r+1;
                                    while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                        dis_r=dis_r+1;
                                    }
                                 }else if((pre_x==cur_x+1)&&(pre_y==cur_y)){
                                    dis_d=dis_d+1;
                                    while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                        dis_d=dis_d+1;
                                    }
                                }
                            }else if(type==4){
                                if((pre_x==cur_x)&&(pre_y==cur_y-1)){
                                    dis_l=dis_l+1;
                                    while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                        dis_l=dis_l+1;
                                    }
                                 }else if((pre_x==cur_x-1)&&(pre_y==cur_y)){
                                    dis_d=dis_d+1;
                                    while(is_corridor(cur_x,cur_y)&&(maze.cell(cur_x,cur_y))){
                                        dis_d=dis_d+1;
                                    }
                                }

                            }
                            generated.push_back(PositionPtr(new Position(cur_x,cur_y,dis_u+dis_d+dis_r+dis_l)));


                        }
                    }


        return generated;
    }
};



int main( int argc, char **argv )
{
    // load file
    std::string filename = "maze.png";
    if(argc == 2)
        filename = std::string(argv[1]);

    // let Point know about this maze
    Position::maze = ecn::Maze(filename);

    // initial and goal positions as Position's
    Position start = Position::maze.start(),
             goal = Position::maze.end();

    // call A* algorithm
    ecn::Astar(start, goal);

    // save final image
    Position::maze.saveSolution("cell");
    cv::waitKey(0);

}
