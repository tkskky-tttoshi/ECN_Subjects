#ifndef SENSOR_RANGE_H
#define SENSOR_RANGE_H

#include <sensor.h>

using namespace arpro;


class RangeSensor : public Sensor
{
public:
    RangeSensor(Robot &_robot, double _x,double _y,double _theta):Sensor(_robot,_x, _y,_theta){}

    void update(const Pose &_p) {
        Pose p1,p2;
        double d;
        double min_d=100000;

        for(int i=0;i<envir_->walls.size();++i){

            p1=envir_->walls[i];
            p2=envir_->walls[(i+1)%envir_->walls.size()];

            if((p1.x*sin(_p.theta)-p2.x*sin(_p.theta)-p1.y*cos(_p.theta)+p2.y*cos(_p.theta))!=0){
               d=((p1.x*p2.y)-(p1.x*_p.y)-(p2.x*p1.y)+(p2.x*_p.y)+(_p.x*p1.y)-(_p.x*p2.y))/(p1.x*sin(_p.theta)-p2.x*sin(_p.theta)-p1.y*cos(_p.theta)+p2.y*cos(_p.theta));

            }
             std::cout<<"  dis: "<<d<<std::endl;
            if((d>0)&&(min_d>d)){
                min_d=d;
            }
        }

        s_=min_d;
        std::cout<<"The distance to the nearest wall:"<<s_<<std::endl;

    }

    void checkTwist(Twist &_t) {
        g_=.1;
        sm_=0.1;
        if(_t.vx>g_*(s_-sm_)){
            _t.vx=g_*(s_-sm_);
        }

    }



};

#endif // SENSOR_RANGE_H

