#ifndef SENSOR_BEARING_H
#define SENSOR_BEARING_H

#include <sensor.h>
using namespace arpro;


class SensorBearing : public Sensor
{
public:
    SensorBearing(Robot &_robot, double _x,double _y,double _theta):Sensor(_robot,_x, _y,_theta){}

    void update(const Pose &_p) {

        double angle=0;
        Pose p;
        for(auto other : envir_->robots_){
            if(other!=robot_){

                std::cout<<"p.theta: "<<_p.theta<<std::endl;
                p=other->pose();
                angle=std::atan2(p.y-_p.y ,p.x-_p.x)-_p.theta;
                std::cout<<"angle: "<<angle<<std::endl;
                break;
            }

        }
        if((angle>M_PI)){
            angle-=2*M_PI;
        }else if(angle<-M_PI){
            angle+=2*M_PI;
        }

        std::cout<<"s_: "<<s_<<std::endl;
        s_=angle;
        std::cout<<"The bearing angle between this and another:"<<s_<<std::endl;

    }

    void checkTwist(Twist &_t) {
        g_=0.5;
        _t.w=_t.w-g_*s_;

    }



};

#endif // SENSOR_RANGE_H

