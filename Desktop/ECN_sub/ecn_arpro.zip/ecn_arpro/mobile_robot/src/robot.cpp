

#include <iostream>
#include <math.h>
#include <robot.h>
#include <sensor_range.h>
#include <cmath>

using namespace arpro;
using namespace std;

Environment* Sensor::envir_ = NULL;

Robot::Robot(string _name, double _x, double _y, double _theta)
{    
    //Q2: this is a constrauctor of class Robot. For example, Robot::Robot("hoge",0,0,0);
    //No. We can't. If the passed arguments are reference, we can change it from main.cpp

    pose_.x = _x;
    pose_.y = _y;
    pose_.theta = _theta;

    name_ = _name;

    // init position history
    x_history_.push_back(_x);
    y_history_.push_back(_y);

    // default sampling time: 1/100 s
    dt_ = .01;

}


void Robot::moveXYT(double _vx, double _vy, double _omega)
{   //Q4: No. We can put it in protected.
    // update position
    pose_.x += _vx*dt_;
    pose_.y += _vy*dt_;
    pose_.theta += _omega*dt_;

    // store position history
    x_history_.push_back(pose_.x);
    y_history_.push_back(pose_.y);
}

//Q5
void Robot::initWheel(double _b, double _r){
    b=_b;
    r=_r;
}

//Q1
void Robot::initWheels(double _b, double _r, double vmax){
    initWheel(_b,_r);
    wheel_angular_limit=vmax;
}


void Robot::rotateWheels(double _left, double _right)
{
    double v,omega;
    bool wheels_init_=true;
    double a;
    double wl=std::fabs(_left)/wheel_angular_limit;
    double wr=std::fabs(_right)/wheel_angular_limit;
//    std::cout<<"wheelmax"<<wheel_angular_limit<<std::endl;
    double new_left,new_right;
    if(r==0||b==0){
        wheels_init_=false;
    }

    if(wheels_init_){

        a=std::max(wl,wr);
//        std::cout<< "a = "<<a<<std::endl;

        if(a<1){
            a=1;
        }else{
//            std::cout<<"here"<<std::endl;

//            std::cout<<"The wheel velocity is over the limit speed"<<std::endl;
//            std::cout<<"The wheel velocity is changed to the limit speed"<<std::endl;
        }

        new_left=_left/a;
        new_right=_right/a;    

if((new_left>10)||(new_right>10))
{std::cout<<"Problem"<<std::endl;}
        v=(new_left+new_right)*r/2;
        omega=(new_left-new_right)*r/(2*b);
        moveXYT(v*cos(pose_.theta),v*sin(pose_.theta),omega);
    }
    // to fill up after defining an initWheel method

}


// move robot with linear and angular velocities
void Robot::moveVW(double _v, double _omega)
{
    // to fill up
    double left,right;
    double vx,vy;

    vx=_v*cos(pose_.theta);
    vy=_v*sin(pose_.theta);

    left=(_v+b*_omega)/r;
    right=(_v-b*_omega)/r;
    rotateWheels(left,right);
//    moveXYT(vx,vy,_omega);



}


// try to go to a given x-y position
void Robot::goTo(const Pose &_p)
{
    // error in robot frame
    Pose error = _p.transformInverse(pose_);

    // try to do a straight line with sensor constraints
    moveWithSensor(Twist(error.x, error.y, 0));
}


void Robot::moveWithSensor(Twist _twist)
{
    // to fill up, sensor measurement and twist checking
    int a=20;
    double v,omega;

    for(auto & sensor: sensors_){
        sensor->updateFromRobotPose(pose_);
        sensor->checkRobotTwist(_twist);
    }

    v=_twist.vx;
    omega=a*_twist.vy+_twist.w;

    //Q3 Vector sensors is the ensemble of sensor data. pose_ is the next pose


    // uses X-Y motion (perfect but impossible in practice)
    //moveXYT(_twist.vx, _twist.vy,_twist.w);


    // to fill up, use V-W motion when defined
    moveVW(v,omega);
}


void Robot::printPosition()
{
    cout << "Current position: " << pose_.x << ", " << pose_.y << endl;
}

