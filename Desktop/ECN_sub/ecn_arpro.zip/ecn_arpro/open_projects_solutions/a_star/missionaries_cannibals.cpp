#include "missionaries_cannibals.h"

MissionariesCannibals::MissionariesCannibals()
{

}
