#ifndef MISSIONARIES_CANNIBALS_H
#define MISSIONARIES_CANNIBALS_H


class MissionariesCannibals
{
public:
  MissionariesCannibals();
};

#endif // MISSIONARIES_CANNIBALS_H