# ARPRO
Advanced Robot Programming Labs for Control and Robotics major at ECN.
Basic exercices to advanced algorithms that may be done in C++ and/or Python.

Open projects are to get used to the syntax by doing small or less small exercises. The solutions are all given but of course it is useless if you have not tried yourself how to do it for some time.

Mobile robot and Maze are used for the assessment (C++ only as it is using existing code).
