#include "xy.h"
#include <iostream>
#include "algo.h"


int main()
{
    XY xy;


    ga(xy);

    xy.print();
}
