#include <sstream>
#include <iostream>
#include <fstream>
#include <yaml-cpp/yaml.h>

int main()
{

}
