#include <visp/vpHomogeneousMatrix.h>

#include <visp/vpPoint.h>
#include <visp/vpSubColVector.h>
#include <visp/vpSubMatrix.h>
#include <visp/vpFeaturePoint.h>
#include <visp/vpFeatureBuilder.h>
#include <visp/vpExponentialMap.h>
#include <visp/vpAdaptiveGain.h>
#include <visp/vpIoTools.h>
#include <fstream>

#include <opencv2/calib3d/calib3d.hpp>

#include <vvs.h>
#include <grid_tracker.h>
#include <perspective_camera.h>
#include <distortion_camera.h>
#include <cb_tracker.h>

using std::cout;
using std::endl;
using std::string;
using std::vector;
using std::stringstream;
using cv::waitKey;
using namespace covis;

int main()
{


    //GridTracker tracker;      // this tracker detects a 6x6 grid of points
    CBTracker tracker(8,6);     // this one is to be given the chessboard dimension (8x6)

    // read images while the corresponding file exists
    // images are displayed to ensure the detection was performed


    cv::VideoCapture cap(0);
    if(!cap.isOpened())
        std::cout<<"Error happened"<<std::endl;
        return -1;




    while(true)
    {

        cv::Mat frame;
        cap>>frame;

        if (frame.empty())
              break;
       std::cout<<"clear 1"<<std::endl;
       Pattern pat;
       pat.im=frame;
       cv::Size size = frame.size();
       int total = size.width * size.height * frame.channels();

       tracker.detect(pat.im, pat.point);
       std::cout<<"clear 2"<<std::endl;
       std::vector<uchar> data(frame.ptr(), frame.ptr()+total);
       std::string s(data.begin(),data.end());
       pat.window=s;
       std::cout<<"clear 3"<<std::endl;

       // draw extraction results
       drawSeq(pat.window, pat.im, pat.point);       

       vpHomogeneousMatrix M;
       bool _reset=true;
       const double pxy=0.5*(pat.im.rows+pat.im.cols);
       std::cout<<"clear 4"<<std::endl;
       PerspectiveCamera cam(pxy,pxy,0.5*pat.im.cols,0.5*pat.im.rows);
       VVS vvs(cam, 0.03, 8, 6);

       vvs.computePose(pat,M,_reset);
       std::cout<<"clear 5"<<std::endl;

       std::cout << "camera pose: " << cam.xi_.t() << std::endl;
       waitKey(0);


    }


    // this will wait for a key pressed to stop the program
    waitKey(0);
}
